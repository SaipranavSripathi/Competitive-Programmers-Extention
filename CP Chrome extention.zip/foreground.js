console.log("From foreground")
